package com.ntt.IIHTSpringSI;

public class simple {
	private int p;
	private  int  r;
	private int  t;
	private int res;
	
	public int getRes() {
		return res;
	}




	public void setRes(int res) {
		this.res = res;
	}




	public simple(){
		
	}
	
	
	
	
	public simple(int p, int r, int t) {
		super();
		this.p = p;
		this.r = r;
		this.t = t;
	}
	public int getP() {
		return p;
	}
	public void setP(int p) {
		this.p = p;
	}
	public int getR() {
		return r;
	}
	public void setR(int r) {
		this.r = r;
	}
	public int getT() {
		return t;
	}
	public void setT(int t) {
		this.t = t;
	}
	public void calc()
	{
		res=(p*t*r)/100;
		
		
		System.out.println("the result is:" +res);
		
	}
    


}
