package com.ntt.collection;

import java.util.List;

public class Employee {

private String name;
private List<String> addr1;
private List<String> addr2;
public Employee(){
	
}
public Employee( String name, List<String> addr1, List<String> addr2) {
	super();
	
	this.name = name;
	this.addr1 = addr1;
	this.addr2 = addr2;
}

public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public List<String> getAddr1() {
	return addr1;
}
public void setAddr1(List<String> addr1) {
	this.addr1 = addr1;
}
public List<String> getAddr2() {
	return addr2;
}
public void setAddr2(List<String> addr2) {
	this.addr2 = addr2;
}


}
