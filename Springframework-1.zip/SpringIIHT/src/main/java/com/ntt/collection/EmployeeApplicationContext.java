package com.ntt.collection;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;



public class EmployeeApplicationContext {

	public static void main(String[] args) {
		ApplicationContext applicationContext=new ClassPathXmlApplicationContext("Employee.xml");
		Employee e1=(Employee)applicationContext.getBean("employee");
		//System.out.println(a1.getNames().get(0));//gives 1st index value
		e1.setName("Ram");
		System.out.println(e1.getName());
		System.out.println(e1.getAddr1());
		System.out.println(e1.getAddr2());

	}

}
